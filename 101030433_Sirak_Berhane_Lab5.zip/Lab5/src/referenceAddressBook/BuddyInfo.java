package referenceAddressBook;
public class BuddyInfo {
	private String fname;
	private String lname;
	private String address;
	private String phoneNumber;
	
	public BuddyInfo(String fname, String lname, String address, String phoneNumber){
		super();
		this.fname = fname;
		this.lname = lname;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}
	
	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public String getLname() {
		return lname;
	}


	public void setLname(String lname) {
		this.lname = lname;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "First Name: \t" + this.getFname() + "\nLast Name: \t" + this.getLname() + "\nAddress: \t" + this.getAddress() + "\nPhone Number: \t" + this.getPhoneNumber();
	}
	

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		// System.out.println("Hello World");
//		
//		// Tests
//		BuddyInfo buddy = new BuddyInfo("John", "Doe", "123 Hello Street", "613-123-4567");
//		
//		System.out.println("First Name: \t" + buddy.getFname());
//		System.out.println("Last Name: \t" + buddy.getLname());
//		System.out.println("Address: \t" + buddy.getAddress());
//		System.out.println("Phone Number: \t" + buddy.getPhoneNumber());
//	}
}
