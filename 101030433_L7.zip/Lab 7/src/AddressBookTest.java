import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class AddressBookTest {

	private BuddyInfo buddy;
	private AddressBook addressbook;
	
	@Before
	public void setUp(){
		buddy = new BuddyInfo("TESTF","TESTL", "TEST1", "222-2", new Date());
		addressbook = new AddressBook();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAdd(){
		addressbook.addBuddy("", "", "", "");
		assertEquals(1, ((List<BuddyInfo>) buddy).size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testClear(){
		addressbook.addBuddy("", "", "", "");
		((List<BuddyInfo>) addressbook).clear();
		assertEquals(0, ((List<BuddyInfo>) buddy).size());
	}
	
	@Test
	public void testSave() throws IOException{
		addressbook.saveFormat("save.txt");
		assertTrue(new File("save.text").exists());
		new File("save.text").delete();
	}
}