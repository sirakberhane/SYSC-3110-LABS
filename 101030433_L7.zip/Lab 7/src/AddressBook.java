import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

public class AddressBook {
	
	// Contains a collection of BuddyInfo data
	private static ArrayList<BuddyInfo> addressBook;
	
	public AddressBook() {
		addressBook = new ArrayList<BuddyInfo>();
	}
	
	/**
	 * Adds the new BuddyInfo to the addressBook collection
	 * @param fname user's first name
	 * @param lname user's last name
	 * @param address user's home address
	 * @param phoneNumber user's home phone number
	 * @return addressBook this contains the updated address 
	 * 		book with the new BuddyInfo data
	 */
	public ArrayList<BuddyInfo> addBuddy(String fname, String lname, String address, String phoneNumber) {
		BuddyInfo addNewBuddy = new BuddyInfo(fname,lname,address,phoneNumber, new Date());
		addressBook.add(addNewBuddy);
		return addressBook;
	}
	
	/**
	 * Get the BuddyInfo at a particular index.
	 * 
	 * @param index get the buddyInfo at this index
	 * @return 
	 */
	public BuddyInfo getBuddyInfoFromAddressBook(int index) {
		return addressBook.get(index);
	}
	
	/**
	 * By default, this method will only remove 
	 * the first item in the collection each 
	 * time this function is called.
	 */
	public void removeBuddy() {
		addressBook.remove(0);
	}
	
	/**
	 * Deletes a BuddyInfo item at a particular index.
	 * 
	 * @param index of the addressBook collection to be deleted
	 */
	public void removeBuddyAtIndex(int index) {
		addressBook.remove(index);
	}
	
	public void saveFormat(String fileName) throws IOException {
		int number = 1;
		BufferedWriter bf = new BufferedWriter(new FileWriter(fileName));
		for (BuddyInfo AB: addressBook) {
			try {
				bf.write( "----------------------------------------------------------------------------------");
				bf.newLine();
				bf.write("BuddyINFO - Contact #" + number);
				bf.newLine();
				bf.write("----------------------------------------------------------------------------------");
				bf.newLine();
				bf.write("First Name:\t\t" + AB.getFname());
				bf.newLine();
				bf.write("Last Name:\t\t" + AB.getLname());
				bf.newLine();
				bf.write("Address:\t\t" + AB.getAddress());
				bf.newLine();
				bf.write("Phone Number:\t\t" + AB.getPhoneNumber());
				bf.newLine();
				bf.write("----------------------------------------------------------------------------------");
				bf.newLine();
				bf.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			number++;
		}
		bf.close();
	}
	
	@Override
	public String toString() {
		int number = 1;
		String Output = "";
		for (BuddyInfo AB: addressBook) {
			 Output += "----------------------------------------------------------------------------------\n" + "BuddyINFO - Contact #" + number + "\n----------------------------------------------------------------------------------\n" + 
					 	"First Name:\t\t" + AB.getFname() + "\nLast Name:\t\t" + AB.getLname() + "\nAddress:\t\t" + AB.getAddress() + "\nPhone Number:\t\t" + AB.getPhoneNumber() + "\n----------------------------------------------------------------------------------\n\n";
			 number++;
		}
		return Output;
	}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		// Tests #0
//		AddressBook addrBook = new AddressBook();
//		addrBook.addBuddy("John", "Doe", "123 Hello Street", "613-123-4567");
//		System.out.println("-----------------------------------------");
//		System.out.println("Address Book\t | \tBuddyInfo");
//		System.out.println("-----------------------------------------");
//		System.out.println("First Name: \t\t" + addrBook.getBuddyInfoFromAddressBook(0).getFname());
//		System.out.println("Last Name: \t\t" + addrBook.getBuddyInfoFromAddressBook(0).getLname());
//		System.out.println("Address: \t\t" + addrBook.getBuddyInfoFromAddressBook(0).getAddress());
//		System.out.println("Phone Number: \t\t" + addrBook.getBuddyInfoFromAddressBook(0).getPhoneNumber());
//		System.out.println("-----------------------------------------\n\n");
//		
//		// Tests #1
//		addrBook.addBuddy("Jane", "Doe", "123 Tree Street", "613-123-8910");
//		System.out.println("-----------------------------------------");
//		System.out.println("Address Book\t | \tBuddyInfo");
//		System.out.println("-----------------------------------------");
//		System.out.println("First Name: \t\t" + addrBook.getBuddyInfoFromAddressBook(1).getFname());
//		System.out.println("Last Name: \t\t" + addrBook.getBuddyInfoFromAddressBook(1).getLname());
//		System.out.println("Address: \t\t" + addrBook.getBuddyInfoFromAddressBook(1).getAddress());
//		System.out.println("Phone Number: \t\t" + addrBook.getBuddyInfoFromAddressBook(1).getPhoneNumber());
//		System.out.println("-----------------------------------------\n\n");
//	}
}
