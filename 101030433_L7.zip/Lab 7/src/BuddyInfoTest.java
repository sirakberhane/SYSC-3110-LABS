import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import java.util.Date;
import org.junit.Before;
import org.junit.jupiter.api.Test;

public class BuddyInfoTest {

	private BuddyInfo buddy;
	private BuddyInfo buddy2;
	
	@Before
	public void setUp() throws Exception {
		buddy = new BuddyInfo("TESTF","TESTL", "TEST1", "222-2", new Date());
		buddy2 = new BuddyInfo("TEST2F","TEST2L", "TEST3", "222-4", new Date());
	}
	
	@Test
	public void testName(){
		assertEquals("TESTF", buddy.getFname());
		assertEquals("TEST2F", buddy2.getFname());
		assertNotEquals("TEST2F", buddy.getFname());	
	}
	
	@Test
	public void testAddress(){
		buddy.setAddress("1 TEST Street");
		assertEquals("1 TEST Street", buddy.getAddress());
	}
	
	@SuppressWarnings("deprecation")
	@Test
	public void testAge(){
		buddy.setBirthday(new Date(1994, 05, 22));
		assertTrue(buddy.isOver18());
	}
	
	@Test
	public void testGreeting(){
		String g = "Hello " + buddy.getFname() + " " + buddy.getLname();
		assertEquals(g, buddy.greetings());
	}	
}
