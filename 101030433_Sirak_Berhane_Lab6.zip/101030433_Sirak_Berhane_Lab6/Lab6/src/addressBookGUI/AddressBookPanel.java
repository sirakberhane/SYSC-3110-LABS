package addressBookGUI;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import referenceAddressBook.AddressBook;

import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JScrollPane;
import java.awt.SystemColor;

public class AddressBookPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = -4105410177619441820L;
	
	// GUI variables 
	private JTextField FirstName;
	private JTextField LastName;
	private JTextField Address;
	private JTextField PhoneNumber;
	private JTextArea textArea;
	private JButton btnSubmit;
	private JMenu mnNewMenu, AddressBook;
	private JMenuItem Contact, Exit, Save, Display;
	private boolean isTextFieldDisabled = false;
	
	// New Contact Variables
	protected String fileName; 
	private AddressBook newAddressBook;
	private String firstName;
	private String lastName;
	private String address;
	private String phoneNumber;
	private boolean oneTimePopUpIsDiplayed = false;
	private int addrBookNum = 1;
	
	/**
	 * Create the panel.
	 */
	public AddressBookPanel() {
		setBackground(SystemColor.controlHighlight);
		setLayout(null);
		createNewMenuBar();
		createTextField();
		addTextFieldLabels();
		disableTextField();
	}
	
	private void createNewMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.activeCaption);
		menuBar.setBounds(0, 0, 450, 21);
		add(menuBar);
		
		mnNewMenu = new JMenu("Settings");
		mnNewMenu.setBackground(SystemColor.activeCaption);
		menuBar.add(mnNewMenu);
		
		AddressBook = new JMenu("New Address Book");
		mnNewMenu.add(AddressBook);
		
		Contact = new JMenuItem("New Contact");
		AddressBook.add(Contact);
		Contact.setBackground(SystemColor.activeCaption);
		Contact.addActionListener(this);
		AddressBook.addActionListener(this);
		
		Save = new JMenuItem("Save");
		Save.setEnabled(false);
		mnNewMenu.add(Save);
		Save.addActionListener(this);
		
		Display = new JMenuItem("Display");
		Display.setEnabled(false);
		mnNewMenu.add(Display);
		Display.addActionListener(this);
		
		Exit = new JMenuItem("Exit");
		Exit.setBackground(SystemColor.activeCaption);
		Exit.setEnabled(false);
		menuBar.add(Exit);
		Exit.addActionListener(this);
	}
	
	private void createTextField() {
		FirstName = new JTextField();
		FirstName.setToolTipText("First Name");
		FirstName.setBounds(132, 52, 308, 20);
		add(FirstName);
		FirstName.setColumns(10);
		
		LastName = new JTextField();
		LastName.setToolTipText("Last Name");
		LastName.setBounds(132, 81, 308, 20);
		add(LastName);
		LastName.setColumns(10);
		
		Address = new JTextField();
		Address.setToolTipText("Address");
		Address.setBounds(132, 112, 308, 20);
		add(Address);
		Address.setColumns(10);
		
		PhoneNumber = new JTextField();
		PhoneNumber.setToolTipText("Phone Number");
		PhoneNumber.setBounds(132, 143, 308, 20);
		add(PhoneNumber);
		PhoneNumber.setColumns(10);
	}
	
	private void addTextFieldLabels() {
		btnSubmit = new JButton("Add Contact");
		btnSubmit.setBackground(SystemColor.activeCaption);
		btnSubmit.setBounds(186, 186, 112, 23);
		btnSubmit.addActionListener(this);
		add(btnSubmit);
		
		JLabel lblFirstName = new JLabel("First Name:");
		lblFirstName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblFirstName.setBounds(10, 51, 118, 19);
		add(lblFirstName);
		
		JLabel lblLastName = new JLabel("Last Name:");
		lblLastName.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblLastName.setBounds(10, 86, 118, 14);
		add(lblLastName);
		
		JLabel lblAddress = new JLabel("Address:");
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAddress.setBounds(10, 115, 118, 14);
		add(lblAddress);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPhoneNumber.setBounds(10, 144, 118, 14);
		add(lblPhoneNumber);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 220, 430, 169);
		add(scrollPane);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setEditable(false);
	}
	
	private JTextField getFirstName() {
		return FirstName;
	}

	private JTextField getLastName() {
		return LastName;
	}

	private JTextField getAddress() {
		return Address;
	}

	private JTextField getPhoneNumber() {
		return PhoneNumber;
	}
	
	private void disableTextField() {
		if(isTextFieldDisabled  == false) {
			FirstName.setEditable(false);
			FirstName.setText("");
			LastName.setEditable(false);
			LastName.setText("");
			Address.setEditable(false);
			Address.setText("");
			PhoneNumber.setEditable(false);
			PhoneNumber.setText("");
			btnSubmit.setEnabled(false);
			isTextFieldDisabled = true;
		}
	}
	
	private void enableTextField() {
		if(isTextFieldDisabled  == true) {
			FirstName.setEditable(true);
			LastName.setEditable(true);
			Address.setEditable(true);
			PhoneNumber.setEditable(true);
			btnSubmit.setEnabled(true);
			isTextFieldDisabled = false;
		}
	}
	
	private void addNewContact () {
		firstName = getFirstName().getText();
		lastName = getLastName().getText();
		address = getAddress().getText();
		phoneNumber = getPhoneNumber().getText();
		
		if (!((firstName.isEmpty()) || (lastName.isEmpty()) || (address.isEmpty()) || (phoneNumber.isEmpty()))) {
			newAddressBook.addBuddy(firstName, lastName, address, phoneNumber);
			disableTextField();
			textArea.setText(textArea.getText()+ "\nContact has been added to address book!");
			AddressBook.setText("Add");
		} else {
			JOptionPane.showMessageDialog(new JFrame(),
				    "One or more textfields are incomplete.",
				    "Incomplete TextField Error",
				    JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void save() {
		fileName = "AddressBook_" + addrBookNum + "_" + new SimpleDateFormat("yyyy-MM-dd").format(new Date()) + ".txt";
		try {
			newAddressBook.saveFormat(fileName);
		} catch (Exception e) {
			textArea.setText("[FAILED TO SAVE] -> " + e);	
		}
		textArea.setText("[SUCCESS] Saved in -> " + fileName);
	}
	
	private void display() {
		textArea.setText(newAddressBook.toString().toString());
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String actionEvent = arg0.getActionCommand();
		
		if (actionEvent == "New Contact") {
			if (oneTimePopUpIsDiplayed == false) {
			newAddressBook = new AddressBook();
			JOptionPane.showMessageDialog(new JFrame(),
				    "New Address Book created!",
				    "SUCCESS",
				    JOptionPane.INFORMATION_MESSAGE);
			oneTimePopUpIsDiplayed = true;
			textArea.setText("New Address Book created!");
			}
			enableTextField();
		}
		
		if (actionEvent == "Add Contact") {
			addNewContact();
			Save.setEnabled(true);
			Display.setEnabled(true);
			Exit.setEnabled(true);
		}
		
		if (actionEvent == "Save") {
			save();
			addrBookNum++;
		}
		
		if (actionEvent == "Display") {
			display();
		}
		
		if (actionEvent == "Exit") {
			//Custom button text
			Object[] options = {"Save", "Exit"};
			int response = JOptionPane.showOptionDialog(new JFrame(),
			    "Make sure address book is saved before exiting.",
			    "Save Address Book",
			    JOptionPane.YES_NO_CANCEL_OPTION,
			    JOptionPane.QUESTION_MESSAGE,
			    null,
			    options,
			    options[1]);
			
			if (response == 0) {
				save();
			} 
			
			if (response == 1) {
				this.setVisible(false);
				AddressBookFrame.exitTriggered();
			}
		}
	}
}
