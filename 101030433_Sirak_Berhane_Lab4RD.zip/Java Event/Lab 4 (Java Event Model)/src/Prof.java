/** SYSC 2101 - Prof-Student-TA Example
 * 
 *
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Prof{
	private String name;
	private Date midtermDate;
	private List<CourseListener> courseListeners;

	public Prof(String aName) {
		this.name = aName;
		courseListeners = new ArrayList<CourseListener>();
	}

	public Date getMidterm() {
		return this.midtermDate;
	}

	public String getName() {
		return this.name;
	}

	public void addCourseListener(CourseListener cl) {
		courseListeners.add(cl);
	}
	
	public void removeCourseListener(CourseListener cl) {
		courseListeners.remove(cl);
	}
	
	public synchronized void setMidterm(Date date) {
		this.midtermDate = date;
		// the prof creates new events and sends it
		CourseEvent event = new CourseEvent(this);
		for(CourseListener listener: courseListeners) {
			listener.midtermAnnouced(event);
		}
	}
	
	public synchronized void postponeMidterm(Date date){
		this.midtermDate = date;
		CourseEvent event = new CourseEvent(this);
		for(CourseListener listener: courseListeners) {
			listener.midtermPostponed(event);
		}
	}
	
	public static void main(String[] args) {
		// Intialize all object instances
		Prof p = new Prof("Babak");
		Student s = new Student("Homer");
		Student s2 = new Student("Bart");
		TeachingAssistant ta = new TeachingAssistant("Michael");
		
		// Add students and TA as Listeners 
		p.addCourseListener(ta);
		p.addCourseListener(s);
		p.addCourseListener(s2);
		
		// Set the midterm date
		Date midterm = new Date();
		p.setMidterm(midterm);
	
		// Change the midterm date and notify all listeners
		p.postponeMidterm(new Date(midterm.getTime() + 1000000000));
	}
}
