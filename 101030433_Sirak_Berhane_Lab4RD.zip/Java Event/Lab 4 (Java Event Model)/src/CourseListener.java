public interface CourseListener {
	 void midtermAnnouced(CourseEvent e);
	 void midtermPostponed(CourseEvent e);
}
