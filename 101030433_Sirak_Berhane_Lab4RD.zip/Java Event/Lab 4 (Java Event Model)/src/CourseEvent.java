import java.util.EventObject;

public class CourseEvent extends EventObject{
	private static final long serialVersionUID = 6152639658588019612L;

	public CourseEvent(Object arg0) {
		super(arg0);
	}
}
